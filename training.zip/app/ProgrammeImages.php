<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class ProgrammeImages extends Model
{
    protected $table = "programme_images";
}
