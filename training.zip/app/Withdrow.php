<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Withdrow extends Model
{
    protected $table = "withdrow_record";
}
