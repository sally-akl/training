<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class ProgrammeIntegrent extends Model
{
    protected $table = "programe_design_integrent";
}
