<footer class="footer footer-transparent">
  <div class="container">
    <div class="row text-center align-items-center flex-row-reverse">
      <div class="col-lg-auto ml-lg-auto">
      </div>
      <div class="col-12 col-lg-auto mt-3 mt-lg-0">
        Copyright © 2020
        <a href="." class="link-secondary">Tabler</a>.
        All rights reserved.
      </div>
    </div>
  </div>
</footer>
