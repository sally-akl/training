<!-- Libs JS -->
<script src="{{ asset('js/jquery/jquery-3.3.1.min.js') }}"></script>
<script src="{{ asset('libs/bootstrap/dist/js/bootstrap.bundle.min.js') }}"></script>

<!-- Tabler Core -->
<script src="{{ asset('js/tabler.min.js') }}"></script>
<script src="{{ asset('libs/apexcharts/dist/apexcharts.min.js') }}"></script>
<script src="{{ asset('libs/jqvmap/dist/jquery.vmap.min.js') }}"></script>
<script src="{{ asset('libs/jqvmap/dist/maps/jquery.vmap.world.js') }}"></script>
<script src="{{ asset('libs/peity/jquery.peity.min.js') }}"></script>
<script src="{{ asset('js/ckeditor.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/flashcanvas.js') }}"></script>
<script src="{{ asset('js/jSignature.min.js') }}"></script>
<script src="{{ asset('js/fileinput.min.js') }}"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script>
  document.body.style.display = "block"
</script>
