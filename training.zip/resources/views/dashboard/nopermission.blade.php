@extends('dashboard.layouts.master')
@section('content')
<div class="empty">
  <div class="alert alert-danger" role="alert">
    You do not have permssions to view this page
  </div>
</div>


@endsection
