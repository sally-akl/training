<meta charset="utf-8">
<title> Home Page </title>

<!-- META DATA -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="author" content="">
<meta name="csrf-token" content="{{ csrf_token() }}">

<link rel="icon" href="img/fav.png" type="image/png" sizes="16x16">


<!-- ============== Resources style ============== -->
<!-- Main Style -->
<link rel="stylesheet" href="{{ asset('assets/css/style.css') }}" />

<!-- Main Style -->
<link rel="stylesheet" href="{{ asset('assets/css/components.css') }}" />

<!-- Bootstrap Style -->
<link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}" />

<!-- Animate css Style -->
<link rel="stylesheet" href="{{ asset('assets/css/animate.css') }}" />

<!-- Owl Carousel css Style -->
<link rel="stylesheet" href="{{ asset('assets/css/owl.carousel.min.css') }}" />
